# Credits

Electroblob's Wizardry  
Version 4.3.7 
For Minecraft 1.12.2

Designed, coded and textured by Electroblob

Thanks to Minecraft Forge and MCP, without which this mod would not have been possible.

Thanks also to the Minecraft modding community, which always has an answer to my modding problems!

In addition, I'd like to thank the following individuals for their contributions to the mod:

#### Discord Moderators (and all-round awesome people)

- FavouriteDragon
- WinDanesz

#### Code

- Corail31
- 12foo
- Shadows-of-Fire
- HellFirePvP
- Tora-B
- Avatair
- Aeronica
- UltraHex
- Azim-Palmer
- raoulvdberge
- rafasoares
- xinyuan-liu
- SettingDust
- Aralu115

#### Translations

- Spanish: MadWrist, Alsentar
- Mexican Spanish: MadWrist
- Russian: VilagVil, kellixon, bigenergy, MugGod2, DrHesperus
- French: Hahdrim, Crowller
- Brazilian Portuguese: lorrampi
- Chinese (Simplified): ZHENGLOC, dragon-evol, Hokorizero, TUsama, Determancer
- Korean: shejery, rewi_wire, 방통, red1854th
- Polish: Trozuu, Olej
- German: BirdyDragon, Lemopav
- Chinese (Traditional): chesterccj305
- Hungarian: Bombadil

#### Sound Effects
- OhhWowProductions
- fredzed
- deleted_user_3277771
- DiscoveryME
- OGSoundFX
- leosalom
- juskiddink