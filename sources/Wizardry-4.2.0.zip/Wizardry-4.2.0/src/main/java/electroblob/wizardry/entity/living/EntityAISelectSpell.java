package electroblob.wizardry.entity.living;

import net.minecraft.entity.ai.EntityAIBase;

public class EntityAISelectSpell extends EntityAIBase {

	// TODO: Write this class

	@Override
	public boolean shouldExecute(){
		return false;
	}

}
