# Credits

Electroblob's Wizardry  
Version 4.1.4
For Minecraft 1.12.2

Designed, coded and textured by Electroblob

Thanks to Minecraft Forge and MCP, without which this mod would not have been possible.

Thanks also to the Minecraft modding community, which always has an answer to my modding problems!

In addition, I'd like to thank the following individuals for their contributions to the mod:

#### Code

- Corail31
- 12foo
- Shadows-of-Fire
- HellFirePvP

#### Translations

- Russian: VilagVil
- Spanish and Mexican Spanish: MadWrist
- Chinese: ZHENGLOC and dragon-evol

Lightning ray sound effect from OhhWowProductions
